#include "mylist.h"
#include <iostream>
using namespace std;

List::List()
	:phead(0)
{
}
List::List(List &other)
	:phead(0)
{
	Node* ptail = 0;
	Node* piter = other.phead;
	while(piter)
	{
		Node* p = new Node;
		p->data = piter->data;
		p->pnext = 0;
		if(ptail)
		{
			ptail->pnext = p;
			ptail = p;
		}
		else
		{
			phead = ptail = p;
		}
		piter = piter->pnext;
	}
//	Node* piter = other.phead;
//	while(piter)
//	{
//		push_back(piter->data);
//		piter = piter->pnext;
//	}

}
List::~List()
{
	while(phead)
	{
		Node* p = phead;
		phead = phead->pnext;
		delete p;
	}
}

void List::push_head(int x)
{
	Node* p = new Node;
	p->data = x;
	p->pnext = phead;
	phead = p;
}
void List::push_back(int x)
{
	Node* p = new Node;
	p->data = x;
	p->pnext = 0;
	Node* piter = phead;
	while(piter &&  piter->pnext)
	{
		piter = piter->pnext;
	}
	if(piter)
	{
		piter->pnext = p;
	}
	else
	{
		phead = p;
	}
}
void List::pop_head(int &ret)
{
	ret = 0;
	if(phead)
	{
		ret = phead->data;
		Node* p = phead;
		phead = phead->pnext;
		delete p;
	}
}
void List::pop_back(int &ret)
{
	ret = 0;
	Node* ppre = 0, *piter=phead;
	while(piter && piter->pnext)
	{
		ppre = piter;
		piter = piter->pnext;
	}
	if(piter)
	{
		ret = piter->data;
		if(ppre)
		{
			ppre->pnext = 0;
		}
		else
		{
			phead = 0;
		}

		delete piter;
	}
}
void List::print()
{
	Node* piter = phead;
	while(piter)
	{
		cout<<piter->data<<"  ";
		piter = piter->pnext;
	}
}
void List::remove(int key)
{
	Node *ppre = 0, * piter = phead;
	while(piter && piter->data != key)
	{
		ppre = piter;
		piter = piter->pnext;
	}
	if(piter)
	{
		if(ppre)
		{
			ppre->pnext = piter->pnext;
		}
		else
		{
			phead = piter->pnext;
		}
		delete piter;
	}
}
void List::insert_before(int key, int x)
{
	Node *ppre = 0, * piter = phead;
	while(piter && piter->data != key)
	{
		ppre = piter;
		piter = piter->pnext;
	}
	if(piter)
	{
		Node* p = new Node;
		p->data = x;
		p->pnext = 0;
		if(ppre)
		{
			ppre->pnext = p;
			p->pnext = piter;
		}
		else
		{
			p->pnext = piter;
			phead = p;
		}
	}

}
void List::insert_after(int key, int x)
{
	Node * piter = phead;
	while(piter && piter->data != key)
	{
		piter = piter->pnext;
	}
	if(piter)
	{
		Node* p = new Node;
		p->data = x;
		p->pnext = piter->pnext;
		piter->pnext = p;
	}
}