//������װ

#pragma once
class List
{
    struct Node
    {
        int data;
        Node *pnext;
    };
    Node *phead;

public:
    List();
    List(List &other);
    ~List();

    void push_head(int x);
    void push_back(int x);
    void pop_head(int &ret);
    void pop_back(int &ret);
    void print();
    void remove(int key);
    void insert_before(int key, int x);
    void insert_after(int key, int x);
};