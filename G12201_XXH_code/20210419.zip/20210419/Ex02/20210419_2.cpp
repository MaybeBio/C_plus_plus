//�Զ���������
#include <iostream>
using namespace std;

class autoArray
{
    int *ptr;
    int count;

public:
	autoArray():ptr(0),count(0){}
    autoArray(autoArray &other)
		: ptr(0), count(other.count)
	{
		if(count)
		{
			ptr = new int[count];
			for(int i=0; i<count; i++)
				ptr[i] = other.ptr[i];
		}
	}
    ~autoArray()
	{
		if(ptr)
		{
			delete[] ptr;
		}
		ptr = 0;
	}
    void push_back(int x)
	{
		int* pnew = new int[count+1];
		for(int i=0; i<count; i++)
			pnew[i] = ptr[i];
		pnew[count++] = x;
		if(ptr)
			delete[] ptr;
		ptr = pnew;
	}
    void push_head(int x)
	{
		int* pnew = new int[count+1];
		for(int i=0; i<count; i++)
			pnew[i+1] = ptr[i];
		pnew[0] = x;
		count++;
		if(ptr)
			delete[] ptr;
		ptr = pnew;
	}
    void pop_back(int &ret)
	{
		if(ptr)
		{
			ret = ptr[count-1];
			int* pnew = new int[count-1];
			count--;
			for(int i=0; i<count; i++)
				pnew[i] = ptr[i];

			delete[] ptr;
			ptr = pnew;
		}
	}
    void pop_head(int &ret)
	{
		if(ptr)
		{
			ret = ptr[count-1];
			int* pnew = new int[count-1];
			for(int i=1; i<count; i++)
				pnew[i-1] = ptr[i];
			count--;
			delete[] ptr;
			ptr = pnew;
		}
	}
    void print()
	{
		for(int i=0; i<count; i++)
			cout<<ptr[i]<<"  ";
		cout<<endl;
	}
    void remove(int key);
    void insert_before(int key, int x);
    void insert_after(int key, int x);
};

int main()
{
    int data = 0;

    autoArray a;
    a.push_back(++data);
    a.push_back(++data);
    a.push_head(++data);
    a.push_head(++data);
    a.print();
    //
    a.insert_before(2, ++data);
    cout << "\ninsert before key=2: ";
    a.print();
    //
    a.insert_after(2, ++data);
    cout << "\ninsert after key=2: ";
    a.print();
    //
    a.remove(2);
    cout << "\nremove key=2: ";
    a.print();
    //
    int x;
    a.pop_head(x);
    cout << "\npop_head,first value=" << x << ", now exist: ";
    a.print();
    //
    a.pop_back(x);
    cout << "\npop_back,last value=" << x << ", now exist: ";
    a.print();
}